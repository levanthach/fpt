<?php
//Start at router for all api requets
header( 'Location: router.php' ) ;
?>